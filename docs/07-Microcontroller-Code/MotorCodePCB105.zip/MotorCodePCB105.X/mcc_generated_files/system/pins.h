/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RB5 aliases
#define IO_RB5_TRIS                 TRISBbits.TRISB5
#define IO_RB5_LAT                  LATBbits.LATB5
#define IO_RB5_PORT                 PORTBbits.RB5
#define IO_RB5_WPU                  WPUBbits.WPUB5
#define IO_RB5_OD                   ODCONBbits.ODCB5
#define IO_RB5_ANS                  ANSELBbits.ANSELB5
#define IO_RB5_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define IO_RB5_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define IO_RB5_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define IO_RB5_GetValue()           PORTBbits.RB5
#define IO_RB5_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define IO_RB5_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define IO_RB5_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define IO_RB5_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define IO_RB5_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define IO_RB5_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define IO_RB5_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define IO_RB5_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RC4 aliases
#define IO_RC4_TRIS                 TRISCbits.TRISC4
#define IO_RC4_LAT                  LATCbits.LATC4
#define IO_RC4_PORT                 PORTCbits.RC4
#define IO_RC4_WPU                  WPUCbits.WPUC4
#define IO_RC4_OD                   ODCONCbits.ODCC4
#define IO_RC4_ANS                  ANSELCbits.ANSELC4
#define IO_RC4_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define IO_RC4_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define IO_RC4_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define IO_RC4_GetValue()           PORTCbits.RC4
#define IO_RC4_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define IO_RC4_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define IO_RC4_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define IO_RC4_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define IO_RC4_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define IO_RC4_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define IO_RC4_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define IO_RC4_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define BUTTON_TRIS                 TRISCbits.TRISC5
#define BUTTON_LAT                  LATCbits.LATC5
#define BUTTON_PORT                 PORTCbits.RC5
#define BUTTON_WPU                  WPUCbits.WPUC5
#define BUTTON_OD                   ODCONCbits.ODCC5
#define BUTTON_ANS                  ANSELCbits.ANSELC5
#define BUTTON_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define BUTTON_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define BUTTON_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define BUTTON_GetValue()           PORTCbits.RC5
#define BUTTON_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define BUTTON_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define BUTTON_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define BUTTON_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define BUTTON_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define BUTTON_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define BUTTON_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define BUTTON_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RC6 aliases
#define IO_RC6_TRIS                 TRISCbits.TRISC6
#define IO_RC6_LAT                  LATCbits.LATC6
#define IO_RC6_PORT                 PORTCbits.RC6
#define IO_RC6_WPU                  WPUCbits.WPUC6
#define IO_RC6_OD                   ODCONCbits.ODCC6
#define IO_RC6_ANS                  ANSELCbits.ANSELC6
#define IO_RC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define IO_RC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define IO_RC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define IO_RC6_GetValue()           PORTCbits.RC6
#define IO_RC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define IO_RC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define IO_RC6_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define IO_RC6_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define IO_RC6_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define IO_RC6_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define IO_RC6_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define IO_RC6_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RD1 aliases
#define IO_RD1_TRIS                 TRISDbits.TRISD1
#define IO_RD1_LAT                  LATDbits.LATD1
#define IO_RD1_PORT                 PORTDbits.RD1
#define IO_RD1_WPU                  WPUDbits.WPUD1
#define IO_RD1_OD                   ODCONDbits.ODCD1
#define IO_RD1_ANS                  ANSELDbits.ANSELD1
#define IO_RD1_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define IO_RD1_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define IO_RD1_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define IO_RD1_GetValue()           PORTDbits.RD1
#define IO_RD1_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define IO_RD1_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define IO_RD1_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define IO_RD1_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define IO_RD1_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define IO_RD1_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define IO_RD1_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define IO_RD1_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define IO_RD2_TRIS                 TRISDbits.TRISD2
#define IO_RD2_LAT                  LATDbits.LATD2
#define IO_RD2_PORT                 PORTDbits.RD2
#define IO_RD2_WPU                  WPUDbits.WPUD2
#define IO_RD2_OD                   ODCONDbits.ODCD2
#define IO_RD2_ANS                  ANSELDbits.ANSELD2
#define IO_RD2_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define IO_RD2_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define IO_RD2_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define IO_RD2_GetValue()           PORTDbits.RD2
#define IO_RD2_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define IO_RD2_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define IO_RD2_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define IO_RD2_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define IO_RD2_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define IO_RD2_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define IO_RD2_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define IO_RD2_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RD5 aliases
#define IO_RD5_TRIS                 TRISDbits.TRISD5
#define IO_RD5_LAT                  LATDbits.LATD5
#define IO_RD5_PORT                 PORTDbits.RD5
#define IO_RD5_WPU                  WPUDbits.WPUD5
#define IO_RD5_OD                   ODCONDbits.ODCD5
#define IO_RD5_ANS                  ANSELDbits.ANSELD5
#define IO_RD5_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define IO_RD5_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define IO_RD5_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define IO_RD5_GetValue()           PORTDbits.RD5
#define IO_RD5_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define IO_RD5_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define IO_RD5_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define IO_RD5_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define IO_RD5_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define IO_RD5_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define IO_RD5_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define IO_RD5_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RD6 aliases
#define IO_RD6_TRIS                 TRISDbits.TRISD6
#define IO_RD6_LAT                  LATDbits.LATD6
#define IO_RD6_PORT                 PORTDbits.RD6
#define IO_RD6_WPU                  WPUDbits.WPUD6
#define IO_RD6_OD                   ODCONDbits.ODCD6
#define IO_RD6_ANS                  ANSELDbits.ANSELD6
#define IO_RD6_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define IO_RD6_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define IO_RD6_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define IO_RD6_GetValue()           PORTDbits.RD6
#define IO_RD6_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define IO_RD6_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define IO_RD6_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define IO_RD6_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define IO_RD6_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define IO_RD6_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define IO_RD6_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define IO_RD6_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RD7 aliases
#define LED_DEBUG_TRIS                 TRISDbits.TRISD7
#define LED_DEBUG_LAT                  LATDbits.LATD7
#define LED_DEBUG_PORT                 PORTDbits.RD7
#define LED_DEBUG_WPU                  WPUDbits.WPUD7
#define LED_DEBUG_OD                   ODCONDbits.ODCD7
#define LED_DEBUG_ANS                  ANSELDbits.ANSELD7
#define LED_DEBUG_SetHigh()            do { LATDbits.LATD7 = 1; } while(0)
#define LED_DEBUG_SetLow()             do { LATDbits.LATD7 = 0; } while(0)
#define LED_DEBUG_Toggle()             do { LATDbits.LATD7 = ~LATDbits.LATD7; } while(0)
#define LED_DEBUG_GetValue()           PORTDbits.RD7
#define LED_DEBUG_SetDigitalInput()    do { TRISDbits.TRISD7 = 1; } while(0)
#define LED_DEBUG_SetDigitalOutput()   do { TRISDbits.TRISD7 = 0; } while(0)
#define LED_DEBUG_SetPullup()          do { WPUDbits.WPUD7 = 1; } while(0)
#define LED_DEBUG_ResetPullup()        do { WPUDbits.WPUD7 = 0; } while(0)
#define LED_DEBUG_SetPushPull()        do { ODCONDbits.ODCD7 = 0; } while(0)
#define LED_DEBUG_SetOpenDrain()       do { ODCONDbits.ODCD7 = 1; } while(0)
#define LED_DEBUG_SetAnalogMode()      do { ANSELDbits.ANSELD7 = 1; } while(0)
#define LED_DEBUG_SetDigitalMode()     do { ANSELDbits.ANSELD7 = 0; } while(0)

// get/set RF4 aliases
#define DEBUGGIN_TRIS                 TRISFbits.TRISF4
#define DEBUGGIN_LAT                  LATFbits.LATF4
#define DEBUGGIN_PORT                 PORTFbits.RF4
#define DEBUGGIN_WPU                  WPUFbits.WPUF4
#define DEBUGGIN_OD                   ODCONFbits.ODCF4
#define DEBUGGIN_ANS                  ANSELFbits.ANSELF4
#define DEBUGGIN_SetHigh()            do { LATFbits.LATF4 = 1; } while(0)
#define DEBUGGIN_SetLow()             do { LATFbits.LATF4 = 0; } while(0)
#define DEBUGGIN_Toggle()             do { LATFbits.LATF4 = ~LATFbits.LATF4; } while(0)
#define DEBUGGIN_GetValue()           PORTFbits.RF4
#define DEBUGGIN_SetDigitalInput()    do { TRISFbits.TRISF4 = 1; } while(0)
#define DEBUGGIN_SetDigitalOutput()   do { TRISFbits.TRISF4 = 0; } while(0)
#define DEBUGGIN_SetPullup()          do { WPUFbits.WPUF4 = 1; } while(0)
#define DEBUGGIN_ResetPullup()        do { WPUFbits.WPUF4 = 0; } while(0)
#define DEBUGGIN_SetPushPull()        do { ODCONFbits.ODCF4 = 0; } while(0)
#define DEBUGGIN_SetOpenDrain()       do { ODCONFbits.ODCF4 = 1; } while(0)
#define DEBUGGIN_SetAnalogMode()      do { ANSELFbits.ANSELF4 = 1; } while(0)
#define DEBUGGIN_SetDigitalMode()     do { ANSELFbits.ANSELF4 = 0; } while(0)

// get/set RF5 aliases
#define MOTOR_PLUS_TRIS                 TRISFbits.TRISF5
#define MOTOR_PLUS_LAT                  LATFbits.LATF5
#define MOTOR_PLUS_PORT                 PORTFbits.RF5
#define MOTOR_PLUS_WPU                  WPUFbits.WPUF5
#define MOTOR_PLUS_OD                   ODCONFbits.ODCF5
#define MOTOR_PLUS_ANS                  ANSELFbits.ANSELF5
#define MOTOR_PLUS_SetHigh()            do { LATFbits.LATF5 = 1; } while(0)
#define MOTOR_PLUS_SetLow()             do { LATFbits.LATF5 = 0; } while(0)
#define MOTOR_PLUS_Toggle()             do { LATFbits.LATF5 = ~LATFbits.LATF5; } while(0)
#define MOTOR_PLUS_GetValue()           PORTFbits.RF5
#define MOTOR_PLUS_SetDigitalInput()    do { TRISFbits.TRISF5 = 1; } while(0)
#define MOTOR_PLUS_SetDigitalOutput()   do { TRISFbits.TRISF5 = 0; } while(0)
#define MOTOR_PLUS_SetPullup()          do { WPUFbits.WPUF5 = 1; } while(0)
#define MOTOR_PLUS_ResetPullup()        do { WPUFbits.WPUF5 = 0; } while(0)
#define MOTOR_PLUS_SetPushPull()        do { ODCONFbits.ODCF5 = 0; } while(0)
#define MOTOR_PLUS_SetOpenDrain()       do { ODCONFbits.ODCF5 = 1; } while(0)
#define MOTOR_PLUS_SetAnalogMode()      do { ANSELFbits.ANSELF5 = 1; } while(0)
#define MOTOR_PLUS_SetDigitalMode()     do { ANSELFbits.ANSELF5 = 0; } while(0)

// get/set RF6 aliases
#define MOTOR_MINUS_TRIS                 TRISFbits.TRISF6
#define MOTOR_MINUS_LAT                  LATFbits.LATF6
#define MOTOR_MINUS_PORT                 PORTFbits.RF6
#define MOTOR_MINUS_WPU                  WPUFbits.WPUF6
#define MOTOR_MINUS_OD                   ODCONFbits.ODCF6
#define MOTOR_MINUS_ANS                  ANSELFbits.ANSELF6
#define MOTOR_MINUS_SetHigh()            do { LATFbits.LATF6 = 1; } while(0)
#define MOTOR_MINUS_SetLow()             do { LATFbits.LATF6 = 0; } while(0)
#define MOTOR_MINUS_Toggle()             do { LATFbits.LATF6 = ~LATFbits.LATF6; } while(0)
#define MOTOR_MINUS_GetValue()           PORTFbits.RF6
#define MOTOR_MINUS_SetDigitalInput()    do { TRISFbits.TRISF6 = 1; } while(0)
#define MOTOR_MINUS_SetDigitalOutput()   do { TRISFbits.TRISF6 = 0; } while(0)
#define MOTOR_MINUS_SetPullup()          do { WPUFbits.WPUF6 = 1; } while(0)
#define MOTOR_MINUS_ResetPullup()        do { WPUFbits.WPUF6 = 0; } while(0)
#define MOTOR_MINUS_SetPushPull()        do { ODCONFbits.ODCF6 = 0; } while(0)
#define MOTOR_MINUS_SetOpenDrain()       do { ODCONFbits.ODCF6 = 1; } while(0)
#define MOTOR_MINUS_SetAnalogMode()      do { ANSELFbits.ANSELF6 = 1; } while(0)
#define MOTOR_MINUS_SetDigitalMode()     do { ANSELFbits.ANSELF6 = 0; } while(0)

// get/set RF7 aliases
#define IO_RF7_TRIS                 TRISFbits.TRISF7
#define IO_RF7_LAT                  LATFbits.LATF7
#define IO_RF7_PORT                 PORTFbits.RF7
#define IO_RF7_WPU                  WPUFbits.WPUF7
#define IO_RF7_OD                   ODCONFbits.ODCF7
#define IO_RF7_ANS                  ANSELFbits.ANSELF7
#define IO_RF7_SetHigh()            do { LATFbits.LATF7 = 1; } while(0)
#define IO_RF7_SetLow()             do { LATFbits.LATF7 = 0; } while(0)
#define IO_RF7_Toggle()             do { LATFbits.LATF7 = ~LATFbits.LATF7; } while(0)
#define IO_RF7_GetValue()           PORTFbits.RF7
#define IO_RF7_SetDigitalInput()    do { TRISFbits.TRISF7 = 1; } while(0)
#define IO_RF7_SetDigitalOutput()   do { TRISFbits.TRISF7 = 0; } while(0)
#define IO_RF7_SetPullup()          do { WPUFbits.WPUF7 = 1; } while(0)
#define IO_RF7_ResetPullup()        do { WPUFbits.WPUF7 = 0; } while(0)
#define IO_RF7_SetPushPull()        do { ODCONFbits.ODCF7 = 0; } while(0)
#define IO_RF7_SetOpenDrain()       do { ODCONFbits.ODCF7 = 1; } while(0)
#define IO_RF7_SetAnalogMode()      do { ANSELFbits.ANSELF7 = 1; } while(0)
#define IO_RF7_SetDigitalMode()     do { ANSELFbits.ANSELF7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/