 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/



/**
 * PIC18F57Q43 H-Bridge Motor Controller with PWM
 * Motor: Pololu 12V Micro Metal Gearmotor 35 RPM
 * 
 * Pin Configuration:
 * - RC5: Button Input (press to toggle direction)
 * - RF5: MOTOR_PLUS - PWM output to H-bridge (forward direction)
 * - RF6: MOTOR_MINUS - PWM output to H-bridge (reverse direction)
 * - RD7: Debug LED
 * - RF1: Debug Button
 * 
 * MCC Custom Pin Names:
 * - RF5 is named "MOTOR_PLUS" in MCC
 * - RF6 is named "MOTOR_MINUS" in MCC
 * 
 * Operation:
 * - Press RC5 (1st time): Motor runs FORWARD while button is held
 * - Release RC5: Motor STOPS
 * - Press RC5 (2nd time): Motor runs REVERSE while button is held
 * - Release RC5: Motor STOPS
 * - Press RC5 (3rd time): Back to FORWARD
 * - Cycle repeats...
 */

#include "mcc_generated_files/system/system.h"

//=============================================================================
// PIN INPUT/OUTPUT DEFINITIONS
//=============================================================================

// INPUT: Read button signal from RC5
#define BUTTON_READ()       PORTCbits.RC5

// OUTPUT: Control debug LED on RD7
#define DEBUG_LED_ON()      LATDbits.LATD7 = 1
#define DEBUG_LED_OFF()     LATDbits.LATD7 = 0

// INPUT: Read debug button on RF1
#define DEBUG_BUTTON_READ() PORTFbits.RF1

//=============================================================================
// PWM CONTROL - Using MCC Generated Functions
//=============================================================================

// PWM OUTPUT on RF5 (MOTOR_PLUS) - Forward direction
#define MOTOR_PLUS_PWM_START()      PWM1_16BIT_Enable()
#define MOTOR_PLUS_PWM_STOP()       PWM1_16BIT_Disable()
#define MOTOR_PLUS_PWM_SET(duty)    PWM1_16BIT_SetSlice1Output1DutyCycleRegister(duty)

// PWM OUTPUT on RF6 (MOTOR_MINUS) - Reverse direction
#define MOTOR_MINUS_PWM_START()     PWM1_16BIT_Enable()
#define MOTOR_MINUS_PWM_STOP()      PWM1_16BIT_Disable()
#define MOTOR_MINUS_PWM_SET(duty)   PWM1_16BIT_SetSlice1Output2DutyCycleRegister(duty)

// PWM duty cycle values (0-65535 for 16-bit PWM)
#define PWM_FULL_SPEED      65535   // 100% duty cycle = full speed
#define PWM_STOP            0       // 0% duty cycle = stop

//=============================================================================
// MOTOR STATE TRACKING
//=============================================================================

typedef enum {
    DIRECTION_FORWARD = 0,    // Next press will run forward
    DIRECTION_REVERSE         // Next press will run reverse
} DirectionMode_t;

// Global variables
volatile DirectionMode_t nextDirection = DIRECTION_FORWARD;
volatile uint8_t lastButtonState = 1;  // Assume button not pressed initially (HIGH with pull-up)
volatile uint8_t motorRunning = 0;     // Track if motor is currently running
volatile uint16_t ledBlinkCounter = 0; // Counter for LED blinking

//=============================================================================
// FUNCTION DECLARATIONS
//=============================================================================

void Motor_Forward(void);
void Motor_Reverse(void);
void Motor_Stop(void);
void Debug_UpdateLED(void);

//=============================================================================
// MAIN PROGRAM
//=============================================================================

int main(void)
{
    //=========================================================================
    // INITIALIZATION - Run once at startup
    //=========================================================================
    
    // Initialize all MCC configured peripherals (PWM, pins, clock, etc.)
    SYSTEM_Initialize();
    
    // Configure RC5 as input if not done in MCC
    TRISCbits.TRISC5 = 1;      // Input
    ANSELCbits.ANSELC5 = 0;    // Digital
    WPUCbits.WPUC5 = 1;        // Enable weak pull-up
    
    // Start with motor stopped
    Motor_Stop();
    
    // Flash LED 3 times to show system is ready
    for(uint8_t i = 0; i < 3; i++)
    {
        DEBUG_LED_ON();
        __delay_ms(100);
        DEBUG_LED_OFF();
        __delay_ms(100);
    }
    
    //=========================================================================
    // MAIN LOOP - Runs continuously forever
    //=========================================================================
    
    while(1)
    {
        //=====================================================================
        // INPUT: Read button signal from RC5
        //=====================================================================
        uint8_t currentButtonState = BUTTON_READ();  // Read RC5 pin (0 or 1)
        
        //=====================================================================
        // BUTTON PRESSED (HIGH signal or button active)
        //=====================================================================
        if(currentButtonState == 1)  // Button is pressed (receiving signal)
        {
            // Check if this is a NEW button press (rising edge)
            if(lastButtonState == 0 && currentButtonState == 1)
            {
                // This is a new press - toggle direction
                if(nextDirection == DIRECTION_FORWARD)
                {
                    nextDirection = DIRECTION_REVERSE;  // Next will be reverse
                }
                else
                {
                    nextDirection = DIRECTION_FORWARD;  // Next will be forward
                }
                __delay_ms(50);  // Debounce delay
            }
            
            // OUTPUT: Run motor in the current direction while button is held
            if(nextDirection == DIRECTION_FORWARD)
            {
                Motor_Forward();       // Run motor forward
                motorRunning = 1;      // Motor is running forward
            }
            else  // nextDirection == DIRECTION_REVERSE
            {
                Motor_Reverse();       // Run motor reverse
                motorRunning = 2;      // Motor is running reverse
            }
        }
        //=====================================================================
        // BUTTON RELEASED (LOW signal - no signal received)
        //=====================================================================
        else  // currentButtonState == 0
        {
            // OUTPUT: Stop motor immediately when button is released
            Motor_Stop();
            motorRunning = 0;  // Motor is stopped
        }
        
        // Update last button state for edge detection
        lastButtonState = currentButtonState;
        
        //=====================================================================
        // DEBUG: Update LED based on motor state
        //=====================================================================
        Debug_UpdateLED();
        ledBlinkCounter++;  // Increment counter for LED blinking
        
        //=====================================================================
        // TIMING: Small delay before next loop iteration
        //=====================================================================
        __delay_ms(10);  // 10ms delay
    }
    
    return 0;
}

//=============================================================================
// MOTOR CONTROL FUNCTIONS
//=============================================================================

/**
 * MOTOR FORWARD FUNCTION
 * 
 * OUTPUT: Sets PWM signals to H-bridge for forward rotation
 * 
 * H-Bridge Logic:
 * - RF5 (MOTOR_PLUS) = PWM at full speed (HIGH pulses)
 * - RF6 (MOTOR_MINUS) = Constant LOW (MUST be disabled)
 * 
 * This creates forward rotation
 */
void Motor_Forward(void)
{
    // CRITICAL: First stop RF6 to prevent both outputs being active
    MOTOR_MINUS_PWM_STOP();              // Disable RF6 completely
    MOTOR_MINUS_PWM_SET(0);              // Set RF6 duty to 0%
    
    // Then start RF5 for forward
    MOTOR_PLUS_PWM_SET(PWM_FULL_SPEED);  // Set RF5 to 100% duty cycle
    MOTOR_PLUS_PWM_START();              // Enable PWM output on RF5
}

/**
 * MOTOR REVERSE FUNCTION
 * 
 * OUTPUT: Sets PWM signals to H-bridge for reverse rotation
 * 
 * H-Bridge Logic:
 * - RF5 (MOTOR_PLUS) = Constant LOW (MUST be disabled)
 * - RF6 (MOTOR_MINUS) = PWM at full speed (HIGH pulses)
 * 
 * This creates reverse rotation
 */
void Motor_Reverse(void)
{
    // CRITICAL: First stop RF5 to prevent both outputs being active
    MOTOR_PLUS_PWM_STOP();               // Disable RF5 completely
    MOTOR_PLUS_PWM_SET(0);               // Set RF5 duty to 0%
    
    // Then start RF6 for reverse
    MOTOR_MINUS_PWM_SET(PWM_FULL_SPEED); // Set RF6 to 100% duty cycle
    MOTOR_MINUS_PWM_START();             // Enable PWM output on RF6
}

/**
 * MOTOR STOP FUNCTION
 * 
 * OUTPUT: Stops motor by disabling both PWM outputs
 * 
 * H-Bridge Logic:
 * - RF5 (MOTOR_PLUS) = LOW
 * - RF6 (MOTOR_MINUS) = LOW
 * 
 * This creates: No voltage differential ? Motor stops (coasts)
 */
void Motor_Stop(void)
{
    // OUTPUT: Disable both PWM outputs and set duty to 0
    MOTOR_PLUS_PWM_STOP();    // Disable RF5
    MOTOR_PLUS_PWM_SET(0);    // Set RF5 duty to 0%
    
    MOTOR_MINUS_PWM_STOP();   // Disable RF6
    MOTOR_MINUS_PWM_SET(0);   // Set RF6 duty to 0%
}

//=============================================================================
// NOTES AND EXPLANATIONS
//=============================================================================

/*
 * OPERATION SUMMARY:
 * 
 * The motor operates based on button presses and releases:
 * 
 * 1. Press button (RC5 = 1): Motor runs in current direction (Forward or Reverse)
 * 2. Release button (RC5 = 0): Motor STOPS
 * 3. Next press: Motor runs in opposite direction
 * 
 * Example sequence:
 * - Press ? FORWARD ? Release ? STOP
 * - Press ? REVERSE ? Release ? STOP
 * - Press ? FORWARD ? Release ? STOP
 * - And so on...
 * 
 * 
 * INPUT vs OUTPUT:
 * 
 * INPUT (Reading):
 * - RC5: BUTTON_READ() detects if button is pressed (1) or released (0)
 * 
 * OUTPUT (Writing):
 * - RF5 (MOTOR_PLUS): PWM signal for forward direction
 * - RF6 (MOTOR_MINUS): PWM signal for reverse direction
 * - RD7: LED indicates forward (ON) or reverse (OFF)
 * 
 * 
 * EDGE DETECTION:
 * 
 * The code uses "edge detection" to determine when the button is released:
 * - lastButtonState = previous state of button
 * - currentButtonState = current state of button
 * - When lastButtonState=1 AND currentButtonState=0 ? Button just released
 * - This triggers the direction toggle for the next press
 */

/**
 * DEBUG LED UPDATE FUNCTION
 * 
 * Updates the debug LED (RD7) with different blink patterns based on motor state:
 * - FORWARD: Fast blink (mostly ON)
 * - REVERSE: Medium blink (equal ON/OFF)
 * - STOP: Slow blink (mostly OFF)
 */
void Debug_UpdateLED(void)
{
    if(motorRunning == 1)  // Motor running FORWARD
    {
        // Fast blink - LED mostly ON
        if(ledBlinkCounter % 20 < 15)  // ON for 15 cycles, OFF for 5
        {
            DEBUG_LED_ON();
        }
        else
        {
            DEBUG_LED_OFF();
        }
    }
    else if(motorRunning == 2)  // Motor running REVERSE
    {
        // Medium blink - Equal ON/OFF
        if(ledBlinkCounter % 40 < 20)  // ON for 20 cycles, OFF for 20
        {
            DEBUG_LED_ON();
        }
        else
        {
            DEBUG_LED_OFF();
        }
    }
    else  // motorRunning == 0, Motor STOPPED
    {
        // Slow blink - LED mostly OFF
        if(ledBlinkCounter % 100 < 10)  // ON for 10 cycles, OFF for 90
        {
            DEBUG_LED_ON();
        }
        else
        {
            DEBUG_LED_OFF();
        }
    }
}